
*********** Readme file for installing and using iSCSI Initiator 2.0 ********

 Please read this file and the release notes before installing and using 
 iSCSI driver. Also consult the iSCSI Initiator users guide for general
 information and troubleshooting suggestions.

*****************************************************************************

     Setting up iSCSI Initiator
     **************************

The iSCSI Initiator 2.0 is setup using an update package executable that
contains all of the files needed for setup. For example the update package
for the retail version of iSCSI 2.0 for x86 is called iSCSI-2.0-x86fre.exe.
To setup all you would need to do is to run this executable and follow the
update wizard. Unattended install is also possible with this executable. 
Please see the Microsoft iSCSI Initiator users guide for more information.

*****************************************************************************
   iSCSI 2.0 can be configured using a control panel applet or using a 
   command line tool called iSCSICLI.


   iSCSICLI is a command line tool that is used to control the iSCSI initiator
   service and HBAs. Given below are some sample usage for iscsicli.exe.

   The following steps need to be performed on the iSCSI initiator machine.

1, Firstly try to "ping" the target machine and make sure
   network connection is okay. Keep in mind that some targets may not support ping
   so you may need another method to test connectivity. In this case one
   possibility could be to telnet to the target portal address to see if
   the target is accepting TCP connections.

2, Run the following command ONCE for each Target machine to be tested.

   iscsicli AddTargetPortal <TargetPortalAddress> <TargetPortalSocket>

   Eg., iscsicli AddTargetPortal 192.172.10.41 3260

   The above command adds target information in the registry for
   the target at IP Address 192.172.10.41 and will connect to target port
   3260.

3, To get a list of target devices on the target machine do

    iscsicli ListTargets T

   Note down the names of the targets you are interested in. Lets say it
   reports a target named iScsiFoo

4, To login into the target, use the LoginTarget command :

iscsicli LoginTarget <TargetName> <ReportToPNP>
                     <TargetPortalAddress> <TargetPortalSocket>
                     <InitiatorInstance> <Port number> <Security Flags>
                     <Login Flags> <Header Digest> <Data Digest>
                     <Max Connections> <DefaultTime2Wait>
                     <DefaultTime2Retain> <Username> <Password> <AuthType> <Key>

                     <Mapping Count> <Target Lun> <OS Bus> <Os Target>
                     <OS Lun> ...

   For example, to login to target iScsiFoo, do :

     iscsicli LoginTarget iScsiFoo T * * * * * * * * * * * * * * * 0

   If this command completes successfully you will see the session id and 
   connection id. To retrieve the session and connection ids later on, you 
   can use the iscsicli SessionList command.

   Since we chose T for ReportToPnP, the target will appear in device manager.
   If the target is a disk, the disk will appear under "Disk drives"
   in device manager. If the target is a tape drive, it'll appear
   under "Tape drives"

   At this point the iSCSI tape drive or the iSCSI disk can be
   used as if it is attached locally.

   If you do not want the device to be reported to PnP, use F for
   ReportToPnP. In this case only the commands ScsiInquiry, 
   ReadCapacity, and ReportLUNs can be used for the session.
   Type "iscsicli ?" to get help on these commands.

     iscsicli LoginTarget iScsiFoo F * * * * * * * * * * * * * * * 0

   If ReportToPnP is F, the device will not appear in device manager.

   To logout from the target type "iscsicli LogoutTarget <SessionId>".
   where sessionid is the id returned by login command.

   In order to use CHAP for logon authentication, the Username and
   the CHAP secret should be passed as arguments to LoginTarget and the
   AuthType passed. The string given in Username is passed in CHAP_N
   by the initiator when it responds to the target's challenge.

   For example, to do one way CHAP, if the Username is Microsoft and 
   secret is iSCSI,

     iscsicli LoginTarget iScsiFoo T * * * * * * * * * * * Microsoft iSCSI 1 * 0   

   If Target Auth or mutual CHAP is desired, use 2 for the AuthType

     iscsicli LoginTarget iScsiFoo T * * * * * * * * * * * Microsoft iSCSI 2 * 0

   The secret is used to compute the digest for both the initiator authentication
   and target authentication.

   Note that if you do want to perform mutual authentication the initiator
   needs to have a secret assigned to it. Use the iscsicli CHAPSecret command.
   Note that there is no way to have more than one secret assigned to the
   initiator.

        iscsicli ChapSecret Secret

   Both initiator and target CHAP secrets should be greater than or equal to
   12 bytes, and less than or equal to 16 bytes if IPsec is not being used.
   It should less than or equal to 16 bytes if IPsec is being used.

   In order to enable header digest alone do the following:

   iscsicli LoginTarget <target name> T * * * * * * 1 * * * * * * * * 0

   In order to enable data digest alone do the following:

   iscsicli LoginTarget <target name> T * * * * * * * 1 * * * * * * * 0

   In order to enable both header & data digest alone do the following:

   iscsicli LoginTarget <target name> T * * * * * * 1 1 * * * * * * * 0

   Also note that the iscsicli command AddTargetPortal may also take a
   set of parameters to establish the CHAP secret and AuthType for the
   discovery login.

   Also note that many of the parameters including the CHAP Secret and AuthType
   to LoginTarget can be preset and persisted by the iSCSI initiator 
   service. Use the iscsicli AddTarget command for this

    iscsicli AddTarget <TargetName> * * * 2 T * * * 4 * * * Microsoft 1 0

   The above command would cache information about <Target Name>. The 2 
   specifies a target flag which indicates that the target is hidden, that
   is will not show up in the ListTargets command unless it is also 
   discovered via another mechanism such as iSNS, SendTargets or HBA Discovery.
   The T tells the service to persist the information. The 4 tells the
   service to cache a value of 4 for the maximum number of connections.
   Microsoft is the shared secret for the target and 1 denotes using one
   way CHAP.

   Be aware that there is an order that the iSCSI initiator service uses 
   to determine what value to use for the login parameters. If the login 
   parameter is  specified on the LoginTarget command that it is used. 
   If it is not specified on the LoginTarget command line then any value 
   cached by the AddTarget command is used.

5, Type "iscsicli ?" from command prompt to get a description of usage.
   In all the commands, Session Id is the id returned by login command.


------------------------------------------------------------------------------
Note that if you have installed the software initiator but want to keep it
from loading and use a hardware HBA initiator instead, you can disable the
software initiator from within device manager.

This might be useful in the case you have a hardware initiator and want to
test with that alone.

------------------------------------------------------------------------------
Troubleshooting


Please see the Microsoft iSCSI Initiator users guide for information.
------------------------------------------------------------------------------
Support

Support for the Microsoft iSCSI initiator package is available through 
Microsoft Product Support Services.  For product support options, please 
see: http://support.microsoft.com

------------------------------------------------------------------------------

     Setting up iSCSI Device Specific Module (DSM)
     *********************************************

This section describes how to install MultiPath software (Microsoft MPIO).
A Device Specific Module (DSM) for iSCSI is included in the iSCSI 2.0 
package. This allows the administrator to configure multiple paths from 
the server to storage using the Microsoft software initiator and iSCSI HBA. 
See the iSCSI users guide for more information.

------------------------------------------------------------------------------





